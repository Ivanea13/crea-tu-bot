module.exports = {
    name: "premium",
    desc: "Sirve para comprobar si eres Premium",
    premium: true,
    run: async (client, message, args, prefix) => {
        message.reply(`Si ves este mensaje, significa que eres un usuario premium! 🌟`)
    }
}

/*
╔═════════════════════════════════════════════════════╗
║    || - || Desarollado por dewstouh#1088 || - ||    ║
║    ----------| discord.gg/MBPsvcphGf |----------    ║
╚═════════════════════════════════════════════════════╝
*/
